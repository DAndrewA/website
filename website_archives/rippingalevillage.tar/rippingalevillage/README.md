www.rippingalevillage.co.uk
===========================
This is where all the code for my edits to the village website will go. The changes will include:
+ adding php support to the events diary so that a database can be used
