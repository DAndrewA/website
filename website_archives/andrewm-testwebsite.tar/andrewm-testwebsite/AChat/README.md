AChat wbsite
============

This is where all the code for the website will be stored. Most likely, the website will be using the github API and OAuth authenticication protocol things. All the code for it is in this directory.